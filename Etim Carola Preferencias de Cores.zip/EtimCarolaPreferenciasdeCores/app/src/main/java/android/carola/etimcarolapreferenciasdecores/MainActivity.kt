package android.carola.etimcarolapreferenciasdecores

import android.carola.etimcarolapreferenciasdecores.databinding.ActivityMainBinding
import android.graphics.Color
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    companion object{
        const val NOME_ARQUIVO = "arquivo_prefes.xml"
    }

    private var cor = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        // supportActionBar!!.hide()

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btnCor1.setOnClickListener{
            cor = "#F84082"
            binding.layoutPrincipal.setBackgroundColor(Color.parseColor(cor))
        }
        binding.btnCor2.setOnClickListener{
            cor = "#FF1362"

        }
        binding.btnCor3.setOnClickListener{
            cor = "#F4598C"

        }
        binding.btnCor4.setOnClickListener{
            cor = "#A60239"

        }
        binding.btnCor5.setOnClickListener{
            cor = "#F478A6"
        }

    }

    fun salvarCor(cor: String){

        binding.layoutPrincipal.setBackgroundColor(Color.parseColor(cor))

        val preferencias = getSharedPreferences(NOME_ARQUIVO, MODE_PRIVATE)
        val editor = preferencias.edit()
        editor.putString("cor", cor)
        editor.putString("nome", "Carola")
        editor.putString("sobrenome", "Valença")
        editor.putInt("idade", 18)
        editor.apply()

        Toast.makeText(this, "Cor salva no arquivo de cores", Toast.LENGTH_LONG).show()
    }

    private fun snackBar(){

    }
}