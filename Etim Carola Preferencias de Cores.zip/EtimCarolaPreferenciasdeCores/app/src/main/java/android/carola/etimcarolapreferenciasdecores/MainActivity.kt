package android.carola.etimcarolapreferenciasdecores

import android.carola.etimcarolapreferenciasdecores.databinding.ActivityMainBinding
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    companion object {
        const val NOME_ARQUIVO = "arquivo_prefes.xml"
    }

    private var cor = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        // supportActionBar!!.hide()

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        binding.btnCor1.setOnClickListener {
            cor = "#F84082"
            salvarCor(cor)
        }
        binding.btnCor2.setOnClickListener {
            cor = "#FF1362"
            salvarCor(cor)


        }
        binding.btnCor3.setOnClickListener {
            cor = "#F4598C"
            salvarCor(cor)


        }
        binding.btnCor4.setOnClickListener {
            cor = "#A60239"
            salvarCor(cor)


        }
        binding.btnCor5.setOnClickListener {
            cor = "#F478A6"
            salvarCor(cor)

        }

    }

    override fun onResume() {
        super.onResume()

        val preferencias = getSharedPreferences(NOME_ARQUIVO, MODE_PRIVATE)
        val cor = preferencias.getString("cor", "")

        if(cor!!.isNotEmpty()){
            binding.layoutPrincipal.setBackgroundColor(Color.parseColor(cor))
        }
    }


   private fun salvarCor(cor: String) {

        binding.layoutPrincipal.setBackgroundColor(Color.parseColor(cor))

        binding.btnTrocar.setOnClickListener {view ->
            val preferencias = getSharedPreferences(NOME_ARQUIVO, MODE_PRIVATE)
            val editor = preferencias.edit()
            editor.putString("cor", cor)
            editor.putString("nome", "Carola")
            editor.putString("sobrenome", "Valença")
            editor.putInt("idade", 18)
            editor.apply()
            snackBar(view)

        }
    }

    private fun snackBar(view: View){
        val snackbar = Snackbar.make(view, "Cor de fundo alterada com sucesso!", Snackbar.LENGTH_INDEFINITE)
        snackbar.setAction("OK"){
        }

        snackbar.setActionTextColor(Color.BLUE)
        snackbar.setActionTextColor(Color.LTGRAY)
        snackbar.setActionTextColor(Color.GREEN)
        snackbar.show()

    }

}