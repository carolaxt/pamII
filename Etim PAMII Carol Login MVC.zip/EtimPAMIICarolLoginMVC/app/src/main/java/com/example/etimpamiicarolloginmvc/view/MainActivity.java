package com.example.etimpamiicarolloginmvc.view;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.etimpamiicarolloginmvc.R;
import com.example.etimpamiicarolloginmvc.controller.UsuarioController;
import com.example.etimpamiicarolloginmvc.model.Usuario;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText email, senha, nome;
    private Button entrar, cadastrar;
    private UsuarioController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // sempre primeiro
        try {
            EdgeToEdge.enable(this);
        } catch (Exception e) {
            Log.w(TAG, "EdgeToEdge falhou (não crítico): " + e.getMessage());
        }

        // inflar layout
        setContentView(R.layout.activity_main);

        initComponents();

        // protege contra findViewById retornando null (causa comum de crash)
        View root = findViewById(R.id.main);
        if (root != null) {
            ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        } else {
            Log.w(TAG, "root (R.id.main) é null — verifique se activity_main.xml tem um View com id 'main'");
        }

        // init controller dentro de try/catch: se o DB falhar, evita crash e mostra mensagem
        try {
            controller = new UsuarioController(MainActivity.this);
        } catch (Exception e) {
            Log.e(TAG, "Erro ao inicializar UsuarioController/DB: ", e);
            Toast.makeText(this, "Erro ao iniciar banco de dados: " + e.getMessage(), Toast.LENGTH_LONG).show();
            // podemos decidir não prosseguir com listeners para evitar mais erros
            return;
        }

        entrar.setOnClickListener(view -> {
            if (!validaCampos()) {
                Toast.makeText(MainActivity.this, "Preencha todos os campos", Toast.LENGTH_LONG).show();
                return;
            }

            String user = safeGetText(email);
            String pass = safeGetText(senha);

            Log.d(TAG, "Tentativa login -> user: " + user);

            boolean isCheckUser = false;
            try {
                isCheckUser = controller.usuarioeSenha(user, pass);
            } catch (Exception e) {
                Log.e(TAG, "Erro ao verificar usuário/senha: ", e);
                Toast.makeText(this, "Erro ao verificar credenciais. Veja Logcat.", Toast.LENGTH_LONG).show();
                return;
            }

            if (isCheckUser) {
                Toast.makeText(MainActivity.this, "Login realizado com sucesso", Toast.LENGTH_LONG).show();
                Intent home = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(home);
            } else {
                Toast.makeText(MainActivity.this, "Usuário ou senha incorretos", Toast.LENGTH_LONG).show();
            }
        });

        cadastrar.setOnClickListener(view -> {
            if (!validaCampos()) {
                Toast.makeText(MainActivity.this, "Preencha todos os campos", Toast.LENGTH_LONG).show();
                return;
            }

            Usuario usuario = new Usuario();
            usuario.setNome(safeGetText(nome));
            usuario.setEmail(safeGetText(email));
            usuario.setSenha(safeGetText(senha));

            Log.d(TAG, "Tentativa cadastro -> email: " + usuario.getEmail());

            boolean sucessoCadastro = false;
            try {
                sucessoCadastro = controller.inserir(usuario);
            } catch (Exception e) {
                Log.e(TAG, "Erro no insert do DB: ", e);
                Toast.makeText(this, "Erro ao cadastrar. Veja Logcat.", Toast.LENGTH_LONG).show();
                return;
            }

            if (sucessoCadastro) {
                Toast.makeText(MainActivity.this, "Cadastro realizado com sucesso", Toast.LENGTH_LONG).show();
                nome.setText("");
                email.setText("");
                senha.setText("");
            } else {
                Toast.makeText(MainActivity.this, "Erro ao cadastrar. Tente novamente.", Toast.LENGTH_LONG).show();
                Log.e(TAG, "insert retornou false (verifique schema/constraints)");
            }
        });
    }

    private String safeGetText(EditText et) {
        if (et == null) return "";
        return et.getText() == null ? "" : et.getText().toString().trim();
    }

    private void initComponents() {
        nome = findViewById(R.id.nome);
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);
        entrar = findViewById(R.id.entrar);
        cadastrar = findViewById(R.id.cadastrar);
    }

    private boolean validaCampos() {
        return !(safeGetText(email).isEmpty() ||
                safeGetText(nome).isEmpty() ||
                safeGetText(senha).isEmpty());
    }
}
