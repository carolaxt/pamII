package com.example.etimpamiicarolloginmvc.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.etimpamiicarolloginmvc.R;
import com.example.etimpamiicarolloginmvc.controller.UsuarioController;
import com.example.etimpamiicarolloginmvc.model.Usuario;

public class MainActivity extends AppCompatActivity {


    private EditText email, senha, nome;
    private Button entrar, criar;
    Usuario usuario;
    UsuarioController controller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        initComponents();
        entrar.setOnClickListener(view -> {
            if (validaCampos() ) {
                usuario = new Usuario();

                usuario.setNome(nome.getText().toString());
                usuario.setEmail(email.getText().toString());
                usuario.setSenha(senha.getText().toString());

                controller = new UsuarioController(this);

                boolean isCheckUser = controller.checkUser(email.getText().toString());
                boolean isCheckPass = controller.checkUserPassword(email.getText().toString(), senha.getText().toString());

                if (isCheckUser && isCheckPass ) {
                    Toast.makeText(this, "Login feito com sucesso!", Toast.LENGTH_LONG);
                }else{
                    Toast.makeText(this, "Usuario ou senha incorretos", Toast.LENGTH_LONG);
                }
            }else{
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_LONG);
            }
        });
    }

    private boolean validaCampos(){
        boolean camposValidos = false;
        if (nome.getText().toString().isEmpty() ||
            email.getText().toString().isEmpty() ||
            senha.getText().toString().isEmpty()){
            camposValidos = false;
        } else {
            camposValidos = true;
        }
        return camposValidos;
    }

    private void initComponents(){
        senha = findViewById(R.id.senha);
        email = findViewById(R.id.email);
        nome = findViewById(R.id.nome);
        entrar = findViewById(R.id.entrar);
        criar = findViewById(R.id.cadastrar);
    }
}