package com.example.etimpamiicarolloginmvc.datamodel;

public class UsuarioDataModel {
}
