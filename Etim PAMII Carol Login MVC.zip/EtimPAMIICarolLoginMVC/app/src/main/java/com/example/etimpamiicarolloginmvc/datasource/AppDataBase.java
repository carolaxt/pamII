package com.example.etimpamiicarolloginmvc.datasource;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import com.example.etimpamiicarolloginmvc.datamodel.UsuarioDataModel;

public class AppDataBase extends SQLiteOpenHelper {
    private static final String TAG = "AppDataBase";
    public static final String DB_NAME = "app.sqlite";
    public static int version = 1;

    public AppDataBase(Context context) {
        super(context, DB_NAME, null, version);
        // NÃO chamar getWritableDatabase() aqui; deixe o Android controlar (evita double init)
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // use o db passado como parâmetro
        try {
            db.execSQL(UsuarioDataModel.criarTabela());
            Log.d(TAG, "Tabela criada com sucesso.");
        } catch (Exception e) {
            Log.e(TAG, "Erro ao criar tabela: ", e);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Implementar política de upgrade (ex: drop + criar) ou migrar colunas corretamente.
        // Para desenvolvimento rápido, você pode dropar e recriar:
        try {
            db.execSQL("DROP TABLE IF EXISTS " + UsuarioDataModel.TABELA);
            onCreate(db);
            Log.d(TAG, "Upgrade DB realizado: " + oldVersion + " -> " + newVersion);
        } catch (Exception e) {
            Log.e(TAG, "Erro no onUpgrade: ", e);
        }
    }

    public boolean insert(String tabela, ContentValues dados) {
        SQLiteDatabase db = null;
        long resultado = -1;
        try {
            db = getWritableDatabase();
            resultado = db.insert(tabela, null, dados);
            return resultado != -1;
        } catch (Exception e) {
            Log.e(TAG, "Erro no insert: ", e);
            return false;
        }
    }

    public Boolean checkUserPassword(String email, String password){
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = getReadableDatabase();
            // use os nomes reais das colunas - aqui eu uso 'email' e 'senha' conforme seu insert
            String sql = "SELECT 1 FROM " + UsuarioDataModel.TABELA + " WHERE email = ? AND senha = ? LIMIT 1";
            cursor = db.rawQuery(sql, new String[]{email, password});
            boolean exists = (cursor != null && cursor.getCount() > 0);
            return exists;
        } catch (Exception e) {
            Log.e(TAG, "Erro em checkUserPassword: ", e);
            return false;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public Boolean checkUser(String email) {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        try {
            db = getReadableDatabase();
            String sql = "SELECT 1 FROM " + UsuarioDataModel.TABELA + " WHERE email = ? LIMIT 1";
            cursor = db.rawQuery(sql, new String[]{email});
            boolean exists = (cursor != null && cursor.getCount() > 0);
            return exists;
        } catch (Exception e) {
            Log.e(TAG, "Erro em checkUser: ", e);
            return false;
        } finally {
            if (cursor != null) cursor.close();
        }
    }
}