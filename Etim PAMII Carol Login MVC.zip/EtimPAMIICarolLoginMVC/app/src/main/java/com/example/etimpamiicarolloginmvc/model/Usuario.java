package com.example.etimpamiicarolloginmvc.model;

public class Usuario {

    private int id;

    private String nome;

    private String email;

    private String senha;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
