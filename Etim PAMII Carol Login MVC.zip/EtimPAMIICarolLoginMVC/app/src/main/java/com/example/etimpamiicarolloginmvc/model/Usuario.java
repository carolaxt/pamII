package com.example.etimpamiicarolloginmvc.model;

public class Usuario {
}
